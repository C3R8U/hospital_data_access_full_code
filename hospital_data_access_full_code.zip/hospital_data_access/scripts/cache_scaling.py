"""Measure the throughput of independent offline slot generators."""
import argparse
import csv
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.abe import AccessEngine
from healthshare.cache_parallel import fill_parallel
from healthshare.data import load_data, add_bins, build_catalog
from healthshare.groups import AlgebraGroup, PBCGroup


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--backend', choices=['algebra-check', 'pbc-a1'], default='algebra-check')
    p.add_argument('--workers', default='1,4,16')
    p.add_argument('--slots', type=int, default=16)
    args = p.parse_args()
    config = json.loads((ROOT/'config/study.json').read_text())
    corpus = add_bins(load_data(ROOT/config['data_file']))
    attrs, _ = build_catalog(corpus)
    if args.backend == 'algebra-check':
        backend = {'backend': 'algebra-check', 'seed': config['seed']+44}
        G = AlgebraGroup(config['seed']+44)
    else:
        backend = {'backend': 'pbc-a1',
                   'parameters': str(ROOT/config['native_pairing_parameter_file']),
                   'generator': str(ROOT/config['native_public_generator_file']),
                   'library': str(ROOT/'build/libhealthshare_pbc.so')}
        G = PBCGroup(backend['parameters'], backend['generator'], backend['library'])
    engine = AccessEngine(G, attrs, config['authority_count'],
                          config['max_matrix_columns'], config['cache_depth'])
    report = []
    for count in map(int, args.workers.split(',')):
        slots, row = fill_parallel(engine, backend, count, args.slots)
        row['backend'] = G.name
        row['serialized_slot_bytes'] = sum(
            len(G.serialize(x)) for x in slots[0].E + slots[0].W +
            [element for parts in slots[0].attr_parts.values() for element in parts])
        report.append(row)
        print(json.dumps(row))
    with (ROOT/'results/cache_parallel.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=report[0].keys())
        writer.writeheader()
        writer.writerows(report)
    if hasattr(G, 'close'): G.close()


if __name__ == '__main__':
    main()
