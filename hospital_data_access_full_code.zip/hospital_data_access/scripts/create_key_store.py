"""Create a password-protected set of independent attribute authority keys."""
import argparse
import json
import os
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.abe import AccessEngine
from healthshare.data import load_data, add_bins, build_catalog
from healthshare.groups import AlgebraGroup, PBCGroup
from healthshare.key_store import save_state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', choices=['algebra-check', 'pbc-a1'], default='pbc-a1')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    password = os.environ.get('HOSPITAL_KEYSTORE_PASSPHRASE')
    if password is None:
        raise ValueError('HOSPITAL_KEYSTORE_PASSPHRASE is required')
    cfg = json.loads((ROOT/'config/study.json').read_text())
    df = add_bins(load_data(ROOT/cfg['data_file']))
    universe, _ = build_catalog(df)
    group = (AlgebraGroup(cfg['seed']+1000) if args.backend == 'algebra-check'
             else PBCGroup(ROOT/cfg['native_pairing_parameter_file'],
                           ROOT/cfg['native_public_generator_file'],
                           ROOT/'build/libhealthshare_pbc.so'))
    engine = AccessEngine(group, universe, cfg['authority_count'],
                          cfg['max_matrix_columns'], cfg['cache_depth'])
    save_state(args.output, engine.private_state(), password)
    if hasattr(group, 'close'): group.close()
    print('Encrypted authority key store created; no private values were printed')


if __name__ == '__main__':
    main()
