"""Collect measured encryption, access, integrity, and storage statistics."""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
results = ROOT/'results'
metrics = json.loads((results/'metrics.json').read_text())
summary = pd.read_csv(results/'performance_summary.csv')
batches = pd.read_csv(results/'verification_batches.csv')
checks = json.loads((results/'integrity_checks.json').read_text())
invalid = json.loads((results/'invalid_request_checks.json').read_text())
ablations = pd.read_csv(results/'ablation.csv')
paired = pd.read_csv(results/'paired_tests.csv')
cache_parallel = pd.read_csv(results/'cache_parallel.csv')
fabric = json.loads((results/'fabric_analysis.json').read_text())
capacity = json.loads((results/'capacity_analysis.json').read_text())


def values_for_metric(metric):
    records = summary[summary.metric == metric].sort_values('policy_rows')
    return [{'attributes': int(row.policy_rows), 'mean': float(row['mean']),
             'sd': float(row['std']), 'ci95': [float(row.ci95_low), float(row.ci95_high)],
             'unit': str(row.unit), 'samples': int(row['count'])}
            for _, row in records.iterrows()]


report = {
    'measurement_backend': metrics['backend'],
    'physical_pairings_measured': metrics['physical_pairings_measured'],
    'security_strength_approved': metrics['security_strength_approved'],
    'fabric_confirmations_available': fabric['fabric_confirmations_available'],
    'dataset': metrics['dataset_profile'],
    'attribute_catalog': {'clinical': metrics['clinical_tokens'],
                          'administrative': metrics['system_tokens'],
                          'total': metrics['total_attributes']},
    'cache': {
        'depth': metrics['cache_depth'],
        'initialization_ms': metrics['cache_setup_ms'],
        'single_slot_refill_ms': metrics['single_slot_refill_ms'],
        'serialized_cache_bytes': metrics['offline_cache_serialized_bytes'],
        'workers_executed': metrics['cache_workers_executed'],
        'ideal_parallel_slots_per_s_not_measured':
            metrics['parallel_cache_capacity_estimate_not_measured_per_s'],
    },
    'policy_results': {metric: values_for_metric(metric) for metric in sorted(summary.metric.unique())},
    'verification_batch_results': batches.to_dict(orient='records'),
    'access_integrity': checks,
    'invalid_request_checks': invalid,
    'component_ablation': ablations.to_dict(orient='records'),
    'paired_hypothesis_tests': paired.to_dict(orient='records'),
    'parallel_offline_computation': cache_parallel.to_dict(orient='records'),
    'signed_stored_metadata_checks': {
        layout: json.loads((results/f'metadata_{layout}_checks.json').read_text())
        for layout in ('single', 'three')
        if (results/f'metadata_{layout}_checks.json').exists()},
    'stored_object_open_checks': {
        layout: json.loads((results/f'roundtrip_{layout}.json').read_text())
        for layout in ('single', 'three')
        if (results/f'roundtrip_{layout}.json').exists()},
    'local_storage_pipeline': {
        'completed': metrics['local_storage_pipeline_completed'],
        'elapsed_s': metrics['local_storage_pipeline_elapsed_s'],
        'local_tps_not_fabric': metrics['local_storage_pipeline_tps_not_fabric'],
    },
    'fabric': fabric,
    'capacity_model': capacity,
}
output = results/'study_summary.json'
output.write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
print('Saved study_summary.json')
print('Data records:', report['dataset']['records'])
print('Group backend:', report['measurement_backend'])
print('Physical pairings:', report['physical_pairings_measured'])
print('Confirmed Fabric TPS available:', report['fabric_confirmations_available'])
print('Local pipeline TPS:', round(report['local_storage_pipeline']['local_tps_not_fabric'], 3))
print(summary[summary.metric.isin(['online_encrypt_ms','user_recovery_ms','edge_transform_ms'])]
      .pivot(index='policy_rows', columns='metric', values='mean').round(4).to_string())
