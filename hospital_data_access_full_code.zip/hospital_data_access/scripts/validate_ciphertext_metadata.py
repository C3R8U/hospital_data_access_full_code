"""Verify the signed off-chain record against its stored transaction fields."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT))
from healthshare.storage import local_path


def canonical(data):
    return json.dumps(data, separators=(',', ':'), sort_keys=True).encode()


def check_item(item):
    record = local_path(item['storage_uri'], ROOT).read_bytes()
    digest = hashlib.sha256(record).hexdigest()
    if digest != item['digest']:
        raise ValueError('The stored ciphertext digest does not match')
    signature = base64.b64decode(item['owner_signature'], validate=True)
    public = Ed25519PublicKey.from_public_bytes(
        base64.b64decode(item['owner_public_key'], validate=True))
    public.verify(signature, record)
    data = json.loads(record)
    policy = data['policy']
    if len(policy['labels']) != item['policy_rows'] or len(data['rows']) != item['policy_rows']:
        raise ValueError('Incorrect policy row count')
    associated = json.loads(base64.b64decode(data['associated'], validate=True))
    if (associated['channel'] != item['channel'] or
            str(associated['version']) != item['version']):
        raise ValueError('Channel or version mismatch')
    salted = base64.b64decode(data['salt'], validate=True) + canonical(policy)
    if associated['policy_digest'] != hashlib.sha256(salted).hexdigest():
        raise ValueError('The access-policy commitment does not match')
    if associated['policy_digest'] != item['policy_digest']:
        raise ValueError('The ledger policy digest does not match')
    if len(record) != item['ciphertext_bytes']:
        raise ValueError('The recorded ciphertext length does not match')
    return item['channel']


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', default='data/derived/fabric_transactions.jsonl')
    p.add_argument('--output', default=None)
    args = p.parse_args()
    path = ROOT / args.input
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    counts = {}
    for item in rows:
        channel = check_item(item)
        counts[channel] = counts.get(channel, 0) + 1
    report = {'checked': len(rows), 'signed_metadata_valid': len(rows),
              'per_channel': counts, 'key_material_required': False}
    if args.output:
        destination = ROOT / args.output
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
