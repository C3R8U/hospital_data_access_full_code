"""Size the clinical publishing queue from its configured workload."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
config = json.loads((ROOT / 'config/study.json').read_text())
metrics = json.loads((ROOT / 'results/metrics.json').read_text())
daily = config['clinical_reports_daily_reference']
window = config['clinical_reporting_hours']
peak = config['clinical_peak_multiplier']
rate = daily / (window * 3600)
refill = metrics['single_slot_refill_ms']
report = {
    'clinical_workload': {'daily_reports_assumed': daily,
                         'reporting_hours_assumed': window,
                         'peak_multiplier_assumed': peak,
                         'average_requests_s': rate,
                         'peak_requests_s': rate * peak},
    'offline_capacity': {'single_slot_measured_ms': refill,
                         'configured_workers': config['cache_workers'],
                         'ideal_slot_capacity_s_not_measured':
                         config['cache_workers'] * 1000 / refill,
                         'slot_capacity_32_workers_s_not_measured': 32 * 1000 / refill},
    'chain_growth': {'daily_transactions_assumed': daily,
                     'average_metadata_bytes_assumed': 1024,
                     'annual_logical_gb': daily * 365 * 1024 / 1e9},
    'source_backend': metrics['backend'],
}
out = ROOT / 'results/capacity_analysis.json'
out.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
