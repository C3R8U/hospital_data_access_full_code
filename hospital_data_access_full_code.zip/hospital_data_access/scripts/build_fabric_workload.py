"""Prepare encrypted metadata records from observed clinical encounters."""
import argparse
import base64
import hashlib
import json
import os
import random
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.groups import AlgebraGroup, PBCGroup
from healthshare.data import load_data, add_bins, build_catalog, record_attributes, patient_payload, sample_records
from healthshare.policy import build_policy
from healthshare.abe import AccessEngine
from healthshare.key_store import load_state
from healthshare.storage import reference


def main():
    arg = argparse.ArgumentParser()
    arg.add_argument("--count", type=int, default=150)
    arg.add_argument("--backend", choices=["algebra-check", "pbc-a1"], default="algebra-check")
    arg.add_argument("--layout", choices=["three", "single"], default="three")
    arg.add_argument("--key-file", default=None)
    arg.add_argument("--output", default=None)
    opts = arg.parse_args()
    cfg = json.loads((ROOT / "config/study.json").read_text())
    df = add_bins(load_data(ROOT / cfg["data_file"]))
    universe, _ = build_catalog(df)
    G = (AlgebraGroup(cfg["seed"] + 1000) if opts.backend == "algebra-check" else
         PBCGroup(ROOT / cfg["native_pairing_parameter_file"],
                  ROOT / cfg["native_public_generator_file"], ROOT / "build/libhealthshare_pbc.so"))
    engine = AccessEngine(G, universe, cfg["authority_count"],
                          cfg["max_matrix_columns"], cfg["cache_depth"])
    if opts.backend == 'pbc-a1' and not opts.key_file:
        raise ValueError('A persistent --key-file is required for stored clinical ciphertext')
    if opts.key_file:
        password = os.environ.get('HOSPITAL_KEYSTORE_PASSPHRASE')
        if not password:
            raise ValueError('HOSPITAL_KEYSTORE_PASSPHRASE is required')
        engine.load_private_state(load_state(opts.key_file, password))
    engine.initialize_cache()
    rng = random.Random(cfg["seed"] + 8)
    suffix = "_single" if opts.layout == "single" else ""
    out_dir = ROOT / f"data/derived/fabric_ciphertexts{suffix}"
    out_dir.mkdir(parents=True, exist_ok=True)
    output = ROOT / (opts.output or f"data/derived/fabric_transactions{suffix}.jsonl")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as dest:
        for index, (row_num, row) in enumerate(sample_records(df, opts.count, cfg["seed"] + 8)):
            channel = ("clinical" if opts.layout == "single" else
                       cfg["fabric_channels"][index % len(cfg["fabric_channels"])])
            held = record_attributes(row, universe, channel)
            size = cfg["policy_sizes"][index % len(cfg["policy_sizes"])]
            policy = build_policy(universe, held, size, cfg["policy_clause_size"], rng)
            if not engine.cache: engine.refill_one()
            package, _, _ = engine.create(policy,
                patient_payload(row, cfg["cipher_payload_bytes"]), channel=channel)
            identifier = hashlib.sha256(f"{cfg['seed']}:{row_num}:{channel}".encode()).hexdigest()[:32]
            name = f"{identifier}.bin"
            file_path = out_dir / name
            file_path.write_bytes(package.record)
            data = json.loads(package.record)
            item = {
                "object_id": identifier, "channel": channel, "digest": hashlib.sha256(package.record).hexdigest(),
                "policy_digest": json.loads(package.associated)["policy_digest"],
                "storage_uri": reference(file_path, ROOT),
                "version": "1", "owner_signature": base64.b64encode(package.signature).decode(),
                "ciphertext_bytes": len(package.record), "source_row": row_num,
                "policy_rows": size, "backend": G.name,
                "owner_public_key": base64.b64encode(engine.signer.public_key().public_bytes_raw()).decode(),
            }
            dest.write(json.dumps(item, sort_keys=True) + "\n")
    print(f"Wrote {opts.count} encrypted metadata entries to {output}")
    print(f"Channel layout: {opts.layout}; group backend: {G.name}")
    print("File URIs are local storage references, not IPFS content addresses")
    if hasattr(G, "close"): G.close()

if __name__ == "__main__": main()
