"""Open stored signed clinical objects with their registered authority keys."""
import argparse
import base64
import hashlib
import json
import os
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.abe import AccessEngine
from healthshare.data import load_data, add_bins, build_catalog, record_attributes, patient_payload
from healthshare.groups import AlgebraGroup, PBCGroup
from healthshare.key_store import load_state
from healthshare.storage import local_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--key-file', required=True)
    parser.add_argument('--input', default='data/derived/fabric_transactions.jsonl')
    parser.add_argument('--limit', type=int, default=10)
    parser.add_argument('--output', default=None)
    parser.add_argument('--ipfs-endpoint', default='http://127.0.0.1:5001')
    args = parser.parse_args()
    password = os.environ.get('HOSPITAL_KEYSTORE_PASSPHRASE')
    if not password:
        raise ValueError('HOSPITAL_KEYSTORE_PASSPHRASE is required')
    config = json.loads((ROOT/'config/study.json').read_text())
    df = add_bins(load_data(ROOT/config['data_file']))
    universe, _ = build_catalog(df)
    inputs = [json.loads(line) for line in (ROOT/args.input).read_text().splitlines() if line]
    if args.limit < 1: raise ValueError('Select at least one object')
    if not inputs: raise ValueError('No encrypted objects')
    backend = inputs[0]['backend']
    if any(item['backend'] != backend for item in inputs):
        raise ValueError('All ciphertexts in one group must use the same backend')
    group = (AlgebraGroup(config['seed']+1000) if backend == 'algebra-check'
             else PBCGroup(ROOT/config['native_pairing_parameter_file'],
                           ROOT/config['native_public_generator_file'],
                           ROOT/'build/libhealthshare_pbc.so'))
    engine = AccessEngine(group, universe, config['authority_count'],
                          config['max_matrix_columns'], config['cache_depth'])
    engine.load_private_state(load_state(args.key_file, password))
    checked = 0
    for item in inputs[:args.limit]:
        if item['storage_uri'].startswith('ipfs://'):
            cid = item['storage_uri'][7:]
            address = args.ipfs_endpoint.rstrip('/') + '/api/v0/cat?arg=' + urllib.parse.quote(cid)
            req = urllib.request.Request(address, method='POST')
            with urllib.request.urlopen(req, timeout=120) as response:
                record = response.read()
        else:
            record = local_path(item['storage_uri'], ROOT).read_bytes()
        signature = base64.b64decode(item['owner_signature'])
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(item['owner_public_key']))
        if public.public_bytes_raw() != engine.signer.public_key().public_bytes_raw():
            raise ValueError('An unregistered signing key was supplied')
        pkg = engine.load_signed_package(record, signature, public,
                                         expected_channel=item['channel'])
        if not engine.preverify(pkg, expected_channel=item['channel'],
                                trusted_public_key=public, metadata=item):
            raise ValueError('Signed metadata did not match its ciphertext')
        row = df.iloc[int(item['source_row'])]
        held = record_attributes(row, universe, channel=item['channel'])
        _, keys = engine.issue_user_keys('registered-clinical-reader', held)
        plaintext = engine.open_verified(pkg, 'registered-clinical-reader', keys,
                                         expected_channel=item['channel'],
                                         trusted_public_key=public, metadata=item)
        if plaintext != patient_payload(row, config['cipher_payload_bytes']):
            raise ValueError('Clinical record contents did not match the encrypted object')
        checked += 1
    if hasattr(group, 'close'): group.close()
    report = {'checked_objects': checked, 'verified_and_decrypted': checked,
              'backend': backend, 'plaintext_exported': False}
    if args.output:
        destination = ROOT / args.output
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
