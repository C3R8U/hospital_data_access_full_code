"""Record a full native-group encryption and delegated recovery transaction."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.abe import AccessEngine
from healthshare.groups import PBCGroup
from healthshare.policy import Policy


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results/native_decryption_trace.json')
    args = parser.parse_args()
    config = json.loads((ROOT / 'config/study.json').read_text())
    parameter_path = ROOT / config['native_pairing_parameter_file']
    generator_path = ROOT / config['native_public_generator_file']
    group = PBCGroup(parameter_path, generator_path,
                     ROOT / 'build/libhealthshare_pbc.so')
    engine = AccessEngine(group, ['laboratory', 'clinical'], authorities=2,
                          max_columns=2, cache_depth=1)
    policy = Policy([[1, 1], [0, -1]], ['laboratory', 'clinical'],
                    [['laboratory'], ['clinical']]).validate(max_columns=2)
    message = b'Signed laboratory and clinical data'
    package, _, _ = engine.create(policy, message, channel='laboratory', from_cache=False)
    _, keys = engine.issue_user_keys('authorized-clinical-reader', set(policy.labels))
    z, blinded_h, blinded_keys = engine.blind('authorized-clinical-reader', keys)
    transformed = engine.transform(package, blinded_h, blinded_keys)
    components = engine.recover_components(package, transformed, z, keys)
    output = engine.open_verified(package, 'authorized-clinical-reader', keys,
                                  expected_channel='laboratory')
    if output != message:
        raise AssertionError('Native pairing decryption failed')
    encode = lambda element: group.serialize(element).hex()
    trace = {
        'backend': 'pbc-a1',
        'parameter_file_sha256': hashlib.sha256(parameter_path.read_bytes()).hexdigest(),
        'generator_file_sha256': hashlib.sha256(generator_path.read_bytes()).hexdigest(),
        'public_generator': encode(group.g), 'base_pairing': encode(engine.eg),
        'matrix': policy.matrix, 'labels': policy.labels,
        'C1': [encode(triple[0]) for triple in package.rows],
        'C2': [encode(triple[1]) for triple in package.rows],
        'C3': [encode(triple[2]) for triple in package.rows],
        'C0': encode(package.c0), 'blinded_identity': encode(blinded_h),
        'blinded_attributes': {name: encode(key) for name, key in blinded_keys.items()},
        'P': encode(transformed), 'L': encode(components['L']),
        'P_z': encode(components['P_z']), 'Z': encode(components['Z']),
        'recovered_R': encode(components['R']),
        'key_confirmation': package.confirmation,
        'ciphertext_package_sha256': hashlib.sha256(package.record).hexdigest(),
        'owner_signature_hex': package.signature.hex(),
        'plaintext_sha256': hashlib.sha256(message).hexdigest(),
        'verified_plaintext': True,
    }
    path = ROOT / args.output
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(trace, indent=2), encoding='utf-8')
    group.close()
    print(f'Saved {path}')


if __name__ == '__main__':
    main()
