"""Draw operation timings and confirmed ledger results from measured tables."""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
results = ROOT / 'results'
figures = results / 'figures'
figures.mkdir(exist_ok=True)
measurements = pd.read_csv(results / 'performance_summary.csv')


def timing_figure(filename, metrics, title, unit='Milliseconds'):
    fig, ax = plt.subplots(figsize=(7.5, 4.3))
    for metric, label in metrics:
        row = measurements[measurements.metric == metric].sort_values('policy_rows')
        ax.errorbar(row.policy_rows, row['mean'],
                    yerr=[row['mean']-row.ci95_low, row.ci95_high-row['mean']],
                    marker='o', capsize=3, label=label)
    ax.set_xlabel('Policy attributes')
    ax.set_ylabel(unit)
    ax.set_title(title)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures / filename, dpi=160)
    plt.close(fig)


timing_figure('encryption.png', [('online_encrypt_ms', 'Cached online'),
                                  ('direct_encrypt_ms', 'Fresh offline and online')],
              'Encryption operations by policy size')
timing_figure('access.png', [('edge_transform_ms', 'Edge transformation'),
                              ('user_recovery_ms', 'User recovery'),
                              ('direct_decrypt_ms', 'Direct decryption')],
              'Access operations by policy size')
timing_figure('integrity.png', [('preverify_ms', 'Package preverification')],
              'Signed package verification by policy size')
timing_figure('ciphertext_size.png', [('ciphertext_bytes', 'Ciphertext bytes')],
              'Encrypted package size by policy size', unit='Bytes')
timing_figure('online_encryption.png', [('online_encrypt_ms', 'Online encryption'),
                                        ('direct_encrypt_ms', 'Direct encryption')],
              'Online and direct encryption timing')
timing_figure('user_recovery.png', [('user_recovery_ms', 'User recovery')],
              'User-side recovery timing')

batches = pd.read_csv(results / 'verification_batches.csv').sort_values('batch_size')
fig, ax = plt.subplots(figsize=(7.5, 4.3))
ax.errorbar(batches.batch_size, batches['mean'],
            yerr=[batches['mean']-batches.ci95_low,
                  batches.ci95_high-batches['mean']], marker='o', capsize=3)
ax.set_xlabel('Ciphertext packages per batch')
ax.set_ylabel('Milliseconds')
ax.set_title('Batch ciphertext preverification')
fig.tight_layout()
fig.savefig(figures / 'verification_batches.png', dpi=160)
plt.close(fig)

fabric_file = results / 'fabric_analysis.json'
if fabric_file.exists():
    fabric = json.loads(fabric_file.read_text())
    if fabric.get('by_load'):
        fig, ax = plt.subplots(figsize=(7.5, 4.3))
        for layout in ('single', 'three'):
            runs = sorted((r for r in fabric['by_load'] if r['layout'] == layout),
                          key=lambda r: r['rate_requested_tps'])
            if not runs:
                continue
            ax.errorbar([r['rate_requested_tps'] for r in runs],
                        [r['committed_tps']['mean'] for r in runs],
                        yerr=[[r['committed_tps']['mean']-r['committed_tps']['ci95_low'] for r in runs],
                              [r['committed_tps']['ci95_high']-r['committed_tps']['mean'] for r in runs]],
                        capsize=3, marker='o', label=layout)
        ax.set_xlabel('Offered request rate per second')
        ax.set_ylabel('Valid committed transactions per second')
        ax.set_title('Fabric metadata transaction throughput')
        ax.legend()
        fig.tight_layout()
        fig.savefig(figures / 'fabric_throughput.png', dpi=160)
        plt.close(fig)
print('Measured figures saved under', figures)
