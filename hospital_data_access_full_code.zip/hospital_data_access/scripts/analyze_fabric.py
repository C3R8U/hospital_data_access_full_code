"""Aggregate gateway commit records and optional channel block events."""
from pathlib import Path
import argparse
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.analysis import summarize_fabric, compare_layouts, summarize_blocks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--block-records', default=None)
    args = parser.parse_args()
    runs = []
    files = [ROOT / f'results/fabric_commits_{layout}.json' for layout in ('single', 'three')]
    for file in files:
        if file.exists():
            runs.extend(json.loads(file.read_text()))
    result = {'connected_trial_files': [str(p.relative_to(ROOT)) for p in files if p.exists()],
              'fabric_confirmations_available': bool(runs)}
    if runs:
        result['by_load'] = summarize_fabric(runs)
        result['channel_comparison'] = compare_layouts(result['by_load'])
    if args.block_records:
        block_path = Path(args.block_records)
        blocks = [json.loads(line) for line in block_path.read_text().splitlines() if line.strip()]
        result['blocks'] = summarize_blocks(blocks)
    out = ROOT / 'results/fabric_analysis.json'
    out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
