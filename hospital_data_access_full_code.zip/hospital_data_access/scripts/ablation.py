"""Measure independent encryption and access components on the same records."""
from pathlib import Path
import csv
import hashlib
import json
import random
import statistics
import sys
import time
from cryptography.exceptions import InvalidTag
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.abe import AccessEngine
from healthshare.data import load_data, add_bins, build_catalog, record_attributes, patient_payload
from healthshare.groups import AlgebraGroup, PBCGroup
from healthshare.policy import build_policy
from healthshare.experiments import elapsed, summarize, save_json, write_csv


def main():
    cfg = json.loads((ROOT / 'config/study.json').read_text())
    raw = pd.read_csv(ROOT / 'results/performance_raw.csv')
    rows = []
    for size, frame in raw.groupby('policy_rows'):
        # Every comparison uses paired timings from the same policy and record.
        configurations = {
            'full': {'online_ms': frame.online_encrypt_ms,
                     'access_ms': frame.total_local_access_ms},
            'direct_encryption': {'online_ms': frame.direct_encrypt_ms,
                                  'access_ms': frame.total_local_access_ms},
            'local_decryption': {'online_ms': frame.online_encrypt_ms,
                                 'access_ms': frame.preverify_ms + frame.direct_decrypt_ms},
            'without_preverification': {
                'online_ms': frame.online_encrypt_ms,
                'access_ms': frame.edge_transform_ms + frame.user_recovery_ms},
        }
        for name, values in configurations.items():
            a, b = summarize(values['online_ms']), summarize(values['access_ms'])
            rows.append({'policy_rows': int(size), 'configuration': name,
                         'backend': str(frame.backend.iloc[0]), 'samples': len(frame),
                         'online_encrypt_mean_ms': a['mean'],
                         'online_encrypt_sd_ms': a['std'],
                         'access_local_mean_ms': b['mean'],
                         'access_local_sd_ms': b['std']})
    write_csv(ROOT / 'results/ablation.csv', rows)

    backend = str(raw.backend.iloc[0])
    if backend == 'pbc-a1':
        group = PBCGroup(ROOT / cfg['native_pairing_parameter_file'],
                         ROOT / cfg['native_public_generator_file'],
                         ROOT / 'build/libhealthshare_pbc.so')
    else:
        group = AlgebraGroup(cfg['seed'] + 813)
    df = add_bins(load_data(ROOT / cfg['data_file']))
    universe, _ = build_catalog(df)
    target = df.iloc[cfg['seed'] % len(df)]
    owned = record_attributes(target, universe)
    policy = build_policy(universe, owned, 100, cfg['policy_clause_size'],
                          random.Random(cfg['seed'] + 43))
    engine = AccessEngine(group, universe, cfg['authority_count'],
                          cfg['max_matrix_columns'], cfg['cache_depth'])
    gid = 'authorized-clinician'
    _, keys = engine.issue_user_keys(gid, owned)
    payload = patient_payload(target, cfg['cipher_payload_bytes'])
    request_count = 100
    rejection_records = []
    for preverification in (True, False):
        rejected = 0
        transforms = 0
        timings = []
        for request in range(request_count):
            package, _, _ = engine.create(policy, payload, from_cache=False)
            package.encrypted = package.encrypted[:-1] + bytes([package.encrypted[-1] ^ 1])
            start = time.perf_counter_ns()
            try:
                if preverification and not engine.preverify(package):
                    rejected += 1
                    continue
                transforms += 1
                z, h, blinded_keys = engine.blind(gid, keys)
                P = engine.transform(package, h, blinded_keys)
                engine.recover(package, P, z, keys)
            except (ValueError, InvalidTag):
                # A changed GCM tag must fail even when the early check is skipped.
                rejected += 1
            finally:
                timings.append((time.perf_counter_ns() - start) / 1e6)
        stats = summarize(timings)
        rejection_records.append({
            'backend': backend, 'preverification_enabled': preverification,
            'requests': request_count, 'rejected': rejected,
            'edge_transform_invocations': transforms,
            'mean_rejection_ms': stats['mean'], 'sd_rejection_ms': stats['std'],
            'ci95_low': stats['ci95_low'], 'ci95_high': stats['ci95_high'],
        })
    save_json(ROOT / 'results/invalid_request_checks.json', rejection_records)
    if hasattr(group, 'close'): group.close()
    print(f'Saved {len(rows)} measured component rows and {len(rejection_records)} invalid-request groups')


if __name__ == '__main__':
    main()
