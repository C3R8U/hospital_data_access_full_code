'use strict';
// Each transaction is counted only after the gateway confirms its commit status.
const fs = require('fs');
const path = require('path');
const grpc = require('@grpc/grpc-js');
const crypto = require('crypto');
const { connect, signers } = require('@hyperledger/fabric-gateway');

const ROOT = path.resolve(__dirname, '..');
const configuration = JSON.parse(fs.readFileSync(path.join(ROOT, 'config/study.json'), 'utf8'));
const network = JSON.parse(fs.readFileSync(path.join(ROOT, 'config/fabric_network.json'), 'utf8'));

function settingsForChannel(channel, gatewaySettings) {
  const chosen = gatewaySettings?.[channel] || {};
  const settings = {
    endpoint: chosen.endpoint || process.env.FABRIC_PEER_ENDPOINT,
    tlsCert: chosen.tls_cert || process.env.FABRIC_TLS_CERT,
    clientCert: chosen.client_cert || process.env.FABRIC_CLIENT_CERT,
    clientKey: chosen.client_key || process.env.FABRIC_CLIENT_KEY,
    mspId: chosen.msp_id || process.env.FABRIC_MSP_ID,
    hostName: chosen.peer_hostname || process.env.FABRIC_PEER_HOSTNAME,
  };
  for (const [name, value] of Object.entries(settings)) {
    if (name !== 'hostName' && !value) {
      throw new Error(`Missing ${name} for channel ${channel}`);
    }
  }
  return settings;
}

function createGateway(channel, setting, contractName) {
  const tls = fs.readFileSync(setting.tlsCert);
  const cert = fs.readFileSync(setting.clientCert);
  const key = crypto.createPrivateKey(fs.readFileSync(setting.clientKey));
  const client = new grpc.Client(setting.endpoint, grpc.credentials.createSsl(tls), {
    'grpc.ssl_target_name_override': setting.hostName || setting.endpoint.split(':')[0],
  });
  const gateway = connect({
    client,
    identity: { mspId: setting.mspId, credentials: cert },
    signer: signers.newPrivateKeySigner(key),
    commitStatusOptions: () => ({ deadline: Date.now() + 30000 }),
  });
  return { client, gateway, contract: gateway.getNetwork(channel).getContract(contractName) };
}

function percentiles(data) {
  if (!data.length) return { p50: null, p95: null, p99: null };
  const sorted = data.slice().sort((a, b) => a - b);
  const pick = q => sorted[Math.min(sorted.length - 1, Math.ceil(q * sorted.length) - 1)];
  return { p50: pick(0.50), p95: pick(0.95), p99: pick(0.99) };
}

async function main() {
  const layout = process.env.FABRIC_LAYOUT || 'three';
  if (!['single', 'three'].includes(layout)) throw new Error('Unknown channel layout');
  const selected = layout === 'single' ? [network.single_channel_comparison.channel]
    : Object.keys(network.channels);
  const credentialMap = process.env.FABRIC_GATEWAYS_JSON
    ? JSON.parse(fs.readFileSync(process.env.FABRIC_GATEWAYS_JSON, 'utf8')) : null;
  const gateways = {};
  try {
    for (const channel of selected) {
      gateways[channel] = createGateway(channel, settingsForChannel(channel, credentialMap),
        process.env.FABRIC_CHAINCODE || network.chaincode);
    }
    const loads = (process.env.FABRIC_LOADS || configuration.fabric_request_rates.join(','))
      .split(',').map(Number);
    const durationMs = Number(process.env.FABRIC_DURATION_MS || configuration.fabric_trial_seconds * 1000);
    const repetitions = Number(process.env.FABRIC_REPETITIONS || configuration.fabric_repetitions);
    const concurrency = Number(process.env.FABRIC_IN_FLIGHT || configuration.fabric_in_flight);
    if (!loads.every(r => r > 0) || durationMs <= 0 || repetitions <= 0 || concurrency <= 0) {
      throw new Error('Invalid load test parameters');
    }
    const templatePath = process.env.FABRIC_TX_FILE || path.join(ROOT, 'data/derived',
      layout === 'single' ? 'fabric_transactions_single.jsonl' : 'fabric_transactions.jsonl');
    const templates = fs.readFileSync(templatePath, 'utf8').trim().split('\n')
      .filter(Boolean).map(line => JSON.parse(line));
    if (!templates.length) throw new Error('Encrypted metadata templates are required');
    for (const item of templates) {
      if (!selected.includes(item.channel)) throw new Error('Template channel is outside selected layout');
      if (item.backend !== 'pbc-a1' && process.env.FABRIC_ALLOW_ALGEBRA_TEST !== '1') {
        throw new Error('Non-cryptographic group fixtures require FABRIC_ALLOW_ALGEBRA_TEST=1');
      }
      if (process.env.FABRIC_REQUIRE_IPFS === '1' && !item.storage_uri.startsWith('ipfs://')) {
        throw new Error('Encrypted objects must be uploaded to IPFS');
      }
    }
    const reports = [];
    for (const rate of loads) {
      for (let repetition = 0; repetition < repetitions; repetition++) {
        const started = performance.now();
        const inflight = new Set();
        const stats = Object.fromEntries(selected.map(c => [c,
          { issued: 0, committed: 0, failed: 0, latency_sample_ms: [], errors: {} }]));
        let issued = 0;
        let droppedByInFlight = 0;
        const deadline = started + durationMs;
        const cap = Math.floor(rate * durationMs / 1000);
        async function put(index) {
          const item = templates[index % templates.length];
          const group = stats[item.channel];
          const objectId = `${item.object_id}-${layout}-${rate}-${repetition}-${index}`;
          const t0 = performance.now();
          try {
            await gateways[item.channel].contract.submitTransaction('PutMetadata', objectId,
              item.digest, item.policy_digest, item.storage_uri, item.channel,
              String(item.version), item.owner_signature);
            group.committed++;
            // Keep bounded samples while retaining the exact commit count.
            if (group.latency_sample_ms.length < 10000) {
              group.latency_sample_ms.push(performance.now() - t0);
            }
          } catch (error) {
            group.failed++;
            const name = error.name || 'CommitError';
            group.errors[name] = (group.errors[name] || 0) + 1;
          }
        }
        for (let index = 0; index < cap; index++) {
          const scheduled = started + (index * 1000 / rate);
          if (scheduled >= deadline) break;
          const delay = scheduled - performance.now();
          if (delay > 1) await new Promise(resolve => setTimeout(resolve, delay));
          if (performance.now() >= deadline) break;
          if (inflight.size >= concurrency) {
            droppedByInFlight++;
            continue;
          }
          const item = templates[index % templates.length];
          stats[item.channel].issued++;
          issued++;
          const pending = put(index).finally(() => inflight.delete(pending));
          inflight.add(pending);
        }
        await Promise.allSettled([...inflight]);
        const durationS = (performance.now() - started) / 1000;
        const channels = {};
        for (const channel of selected) {
          const item = stats[channel];
          channels[channel] = {
            issued: item.issued, committed: item.committed, failed: item.failed,
            committed_tps: item.committed / durationS,
            commit_latency_ms: percentiles(item.latency_sample_ms),
            commit_latency_sample_count: item.latency_sample_ms.length,
            failure_types: item.errors,
          };
        }
        const committed = Object.values(channels).reduce((s, row) => s + row.committed, 0);
        const failed = Object.values(channels).reduce((s, row) => s + row.failed, 0);
        const report = {
          layout, rate_requested_tps: rate, repetition, elapsed_seconds: durationS,
          measurement_window_seconds: durationMs / 1000, in_flight_limit: concurrency,
          peer_count_configured: 6, orderer_count_configured: 3,
          batch_max_message_count: network.batching.max_message_count,
          batch_timeout_ms: network.batching.batch_timeout_ms,
          proposed: issued, skipped_concurrency: droppedByInFlight, committed, failed,
          offered_tps: issued / (durationMs / 1000), committed_tps: committed / durationS,
          channels,
        };
        if (committed + failed !== issued) throw new Error('Commit accounting does not balance');
        reports.push(report);
        console.log(JSON.stringify(report));
      }
    }
    const resultsDirectory = path.join(ROOT, 'results');
    fs.mkdirSync(resultsDirectory, { recursive: true });
    const output = process.env.FABRIC_RESULT_FILE || path.join(resultsDirectory,
      layout === 'single' ? 'fabric_commits_single.json' : 'fabric_commits_three.json');
    fs.writeFileSync(output, JSON.stringify(reports, null, 2));
  } finally {
    for (const item of Object.values(gateways)) {
      item.gateway.close();
      item.client.close();
    }
  }
}

main().catch(error => { console.error(error.stack || error.message); process.exitCode = 1; });
