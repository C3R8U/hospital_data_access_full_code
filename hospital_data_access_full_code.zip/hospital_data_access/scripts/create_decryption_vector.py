"""Save the public algebra fixture and check its recovery result."""
import argparse
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.vectors import create_known_answer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="tests/vectors/decryption.json")
    args = parser.parse_args()
    trace, _, _, _ = create_known_answer()
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(trace, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Saved {output} with {len(trace['intermediate'])} intermediate fields")


if __name__ == "__main__":
    main()
