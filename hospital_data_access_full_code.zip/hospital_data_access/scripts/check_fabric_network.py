"""Inspect the static channel and ordering layout."""
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from healthshare.fabric_config import load_network, transaction_rate_bounds


def main():
    network = load_network(ROOT / 'config/fabric_network.json')
    print(json.dumps({
        'channels': network['channels'],
        'orderers': network['orderers'],
        'batching': network['batching'],
        'timeout_model': transaction_rate_bounds(20, len(network['channels']), 100),
        'configuration_checked': True,
        'live_network_checked': False,
    }, indent=2))


if __name__ == '__main__':
    main()
