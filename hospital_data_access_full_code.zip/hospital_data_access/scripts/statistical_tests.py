"""Paired timing tests across the same access policies and clinical records."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import ttest_rel

ROOT = Path(__file__).resolve().parents[1]
trials = pd.read_csv(ROOT / 'results/performance_raw.csv')
tests = []
for size, rows in trials.groupby('policy_rows'):
    comparisons = (
        ('direct_encrypt_vs_cached_online', rows.direct_encrypt_ms.to_numpy(),
         rows.online_encrypt_ms.to_numpy()),
        ('direct_decrypt_vs_transform_plus_recovery', rows.direct_decrypt_ms.to_numpy(),
         (rows.edge_transform_ms + rows.user_recovery_ms).to_numpy()),
    )
    for name, left, right in comparisons:
        difference = left - right
        statistic, p_value = ttest_rel(left, right, alternative='two-sided')
        sd = difference.std(ddof=1)
        tests.append({
            'policy_rows': int(size), 'comparison': name,
            'test': 'two-sided paired Student t test',
            'paired_count': int(len(left)), 'statistic_t': float(statistic),
            'p_value': float(p_value), 'mean_difference_ms': float(difference.mean()),
            'mean_left_ms': float(left.mean()), 'mean_right_ms': float(right.mean()),
            'paired_cohens_dz': float(difference.mean() / sd) if sd > 0 else np.nan,
        })
output = pd.DataFrame(tests).sort_values('p_value').reset_index(drop=True)
m = len(output)
raw_corrected = [(m-i) * p for i, p in enumerate(output.p_value)]
output['p_holm'] = np.maximum.accumulate(np.minimum(raw_corrected, 1.0))
output.sort_values(['policy_rows', 'comparison']).to_csv(
    ROOT / 'results/paired_tests.csv', index=False)
print('Saved paired timing tests to results/paired_tests.csv')
