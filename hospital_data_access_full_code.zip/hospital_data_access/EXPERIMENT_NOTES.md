# Hospital Data Access Bench

The data access layer uses a multi-authority monotone LSSS policy, independent
one-use offline encryption tuples, blinded pairing transformation, AES-128-GCM,
Ed25519 signatures, and SHA-256 integrity checks.

## Input files

- `data/raw/diabetic_data.csv`: hospital encounter records.
- `data/raw/IDS_mapping.csv`: original categorical code descriptions.
- `config/study.json`: seed, attribute universe size, access policies, pairing
  target parameters, cache controls, and benchmark repetitions.

The 120 authorization attributes consist of 108 frequent clinical categories and
12 administrative attributes. The token dictionary is saved under
`data/derived/attribute_catalog.csv`. Policy conditions are derived from
categorical fields and user authorization context; readmission classes are not
prediction targets. There is no classification or regression training step.

## Available execution modes

`algebra-check` uses a compact exponent representation to test algebraic
identities and code paths. This mode cannot establish cryptographic security,
physical pairing performance, or production encryption throughput.

`pbc-a1` uses the native PBC pairing library. Install PBC 0.5.14 and GMP on the
machine that will execute native workloads. Then run:

```bash
bash scripts/build_native.sh
python scripts/create_pairing_parameters.py --bits 1024
python scripts/run_experiment.py --backend pbc-a1
```

The PBC parameter generator keeps subgroup factors out of the public output.
Do not publish factor files, private user keys, or plaintext medical records.
Assess the full pairing curve and target finite field before claiming a
cryptographic security level. A 3072-bit composite group order alone does not
prove 128-bit security.

For algebra and application control-flow tests:

```bash
python -m pytest -q tests/
python scripts/run_experiment.py --backend algebra-check
python scripts/make_figures.py
python scripts/summarize_results.py
```

## Produced files

- `results/run.log`: initialization, workload progress, and environment status.
- `results/training.log`: dataset and attribute-policy build stages. No model is fit.
- `results/performance_raw.csv`: individual operation timings.
- `results/performance_summary.csv`: means, sample SD, and 95% intervals.
- `results/metrics.json`: corpus facts, cache timing, local pipeline, hardware.
- `results/dataset_profile.json`: dataset counts and missing category counts.
- `results/integrity_checks.json`: invalid transform and cross-channel checks.
- `results/local_metadata.sqlite`: local transaction records for storage checks.
- `results/figures/`: operation timings and ciphertext size.
- `data/derived/policy_instances.jsonl`: generated matrices and user attributes.

## Deployment measurements

The test process only reports operations that it actually executes. Local SQLite
storage is useful for checking the path from encryption to a signed digest,
but is not a Hyperledger Fabric orderer or endorsement service. Independent
Fabric measurements require a running Fabric network and the separately
provided chaincode and gateway client. CPU values and confidence intervals
refer to the host that ran the experiments, not to an Intel i9 or a VM unless
that is the host actually used.

## Metadata channels

The gateway client reads encrypted transaction templates from
`data/derived/fabric_transactions.jsonl`. Run:

```bash
python scripts/build_fabric_workload.py --count 150 --backend pbc-a1
python scripts/ipfs_upload.py --endpoint http://127.0.0.1:5001
cd scripts && npm install
FABRIC_REQUIRE_IPFS=1 node fabric_load.js
```

The chaincode under `chaincode/metadata/` must be deployed on all three
channels before starting the gateway client. Set the peer endpoint, identity
certificate, identity private key, TLS certificate, and MSP identifier through
the documented environment variables in the JavaScript source. The gateway
logs confirmed transactions, not merely queued submissions. The prepared
metadata inputs use actual signed encrypted hospital records. Nonproduction
algebra-check inputs are suitable for connectivity tests, not patient-data
security claims.

See `MODEL_SPEC.md` for the group identities, key construction, LSSS shares,
ciphertext components, and timing boundaries.

## Signing keys and stored-object access

Authority keys are created once and stored under a password-protected path
outside the project directory. Set `HOSPITAL_KEYSTORE_PASSPHRASE` before using
these commands:

```bash
python scripts/create_key_store.py --backend pbc-a1 --output /secure/path/authority.enc
python scripts/build_fabric_workload.py --backend pbc-a1 --layout three --key-file /secure/path/authority.enc
python scripts/check_ciphertext_roundtrip.py --key-file /secure/path/authority.enc --limit 10
```

For an algebra-only connectivity test, use `--backend algebra-check` when
creating the key store and encrypted workload. Those group records are not
clinical confidentiality guarantees.

## Fabric measurements

The channel map and endorsement organizations are defined in
`config/fabric_network.json`. The Gateway client accepts per-channel TLS and
membership credentials through `FABRIC_GATEWAYS_JSON`, a JSON file keyed by
channel with `endpoint`, `tls_cert`, `client_cert`, `client_key`, and `msp_id`.
Its request-rate schedule, concurrency bound, block size, and timeout are
configured in `config/study.json`. Both layouts have distinct encrypted input
files so their signed channel contexts are never relabeled.

```bash
FABRIC_LAYOUT=single node scripts/fabric_load.js
FABRIC_LAYOUT=three node scripts/fabric_load.js
python scripts/analyze_fabric.py
```

An optional block-event JSONL input may be supplied to the analyzer using
`--block-records`. Each event contains `channel`, `number`, `timestamp_ms`, and
`transaction_count`. Absent a live network, Fabric confirmed TPS remains
unavailable. No local SQL or algebra backend value is labeled Fabric TPS.

## Operation summaries

```bash
python scripts/create_decryption_vector.py
python -m pytest -q tests/
python scripts/run_experiment.py --backend algebra-check
python scripts/statistical_tests.py
python scripts/ablation.py
python scripts/capacity_analysis.py
python scripts/analyze_fabric.py
python scripts/make_figures.py
python scripts/summarize_results.py
```

The paired timing analysis uses a two-sided paired Student t test and a
Holm adjustment across the defined comparisons. The local storage, group
arithmetic, native pairing, and Fabric outcomes are recorded separately.

When native pairing parameters are available, `scripts/create_native_trace.py`
records the actual serialized ciphertext elements, outsourced transformation,
local reconstruction product, and plaintext confirmation. The small public
arithmetic fixture under `tests/vectors/` remains separate from native timing.
