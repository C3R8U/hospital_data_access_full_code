"""Native pairing checks run when public PBC parameters are installed."""
from pathlib import Path
import pytest
from healthshare.abe import AccessEngine
from healthshare.groups import PBCGroup
from healthshare.policy import Policy

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [ROOT/'build/libhealthshare_pbc.so', ROOT/'params/public/a1.param',
            ROOT/'params/public/g1.bin']


@pytest.mark.skipif(not all(path.is_file() for path in REQUIRED),
                    reason='PBC binaries and public parameters are not installed')
def test_native_group_recovery():
    group = PBCGroup(REQUIRED[1], REQUIRED[2], REQUIRED[0])
    engine = AccessEngine(group, ['clinical', 'laboratory'], authorities=2,
                          max_columns=2, cache_depth=1)
    policy = Policy([[1, 1], [0, -1]], ['clinical', 'laboratory'],
                    [['clinical'], ['laboratory']]).validate(max_columns=2)
    package, _, _ = engine.create(policy, b'Native pairing check', from_cache=False)
    _, keys = engine.issue_user_keys('doctor-17', {'clinical', 'laboratory'})
    assert engine.open_verified(package, 'doctor-17', keys) == b'Native pairing check'
    group.close()
