"""Network accounting and policy-boundary checks."""
from pathlib import Path
import random
import pytest
from healthshare.policy import Policy, build_policy
from healthshare.fabric_config import load_network, transaction_rate_bounds
from healthshare.analysis import summarize_fabric, compare_layouts, summarize_blocks

ROOT = Path(__file__).resolve().parents[1]


def test_channel_layout():
    configuration = load_network(ROOT / 'config/fabric_network.json')
    assert len(configuration['channels']) == 3
    assert len(set(sum((v['peers'] for v in configuration['channels'].values()), []))) == 6
    assert all(len(x['endorsers']) == 2 for x in configuration['channels'].values())
    model = transaction_rate_bounds(20, 3, 100, 30, 0.03)
    assert model['fixed_timeout_baseline_tps'] == 600
    assert model['full_block_interval_ms_per_channel'] < 100
    assert not model['batch_timeout_is_hard_tps_limit']


def test_channel_ledger_accounting():
    runs = []
    for layout in ('single', 'three'):
        count = 110 if layout == 'single' else 210
        runs.append({'layout': layout, 'rate_requested_tps': 300,
            'committed': count, 'failed': 0, 'proposed': count,
            'elapsed_seconds': 1, 'offered_tps': count,
            'skipped_concurrency': 0,
            'channels': {'clinical': {'committed': count, 'committed_tps': count}}})
    summary = summarize_fabric(runs)
    comparison = compare_layouts(summary)
    assert len(comparison) == 1
    assert comparison[0]['speedup'] == pytest.approx(210/110)
    blocks = [{'channel': 'clinical', 'number': i,
               'transaction_count': 20, 'timestamp_ms': i * 25} for i in range(5)]
    blocks_report = summarize_blocks(blocks)[0]
    assert blocks_report['full_blocks'] == 5
    assert blocks_report['mean_block_interval_ms'] == 25


def test_policy_bounds_and_reconstruction():
    universe = [f'x{i}' for i in range(120)]
    authorized = set(universe[::3])
    for count in (20, 40, 60, 80, 100):
        p = build_policy(universe, authorized, count, 20, random.Random(count))
        assert all(len(clause) <= 20 for clause in p.clauses)
        assert p.column_count <= 16
        assert p.witness(authorized) is not None
    with pytest.raises(ValueError):
        Policy([[1, 2]], ['x'], [['x']]).validate()
    with pytest.raises(ValueError):
        Policy([[1], [0]], ['x', 'x'], [['x'], ['x']]).validate()
