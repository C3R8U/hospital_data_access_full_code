"""Authority key storage keeps ciphertext access working after a restart."""
from pathlib import Path
import random
import pytest
from healthshare.abe import AccessEngine
from healthshare.groups import AlgebraGroup
from healthshare.policy import build_policy
from healthshare.key_store import save_state, load_state


def test_saved_authority_keys(tmp_path):
    universe = [f'a{i}' for i in range(40)]
    held = set(universe[::2])
    engine = AccessEngine(AlgebraGroup(77), universe, max_columns=16)
    policy = build_policy(universe, held, 20, 20, random.Random(88))
    package, _, _ = engine.create(policy, b'Clinical observations', channel='laboratory',
                                  from_cache=False)
    file = tmp_path / 'keys.enc'
    save_state(file, engine.private_state(), 'a-private-test-passphrase')
    if hasattr(file.stat(), 'st_mode'):
        assert file.stat().st_mode & 0o077 == 0
    with pytest.raises(FileExistsError):
        save_state(file, engine.private_state(), 'a-private-test-passphrase')
    with pytest.raises(Exception):
        load_state(file, 'incorrect-passphrase')
    second = AccessEngine(AlgebraGroup(88), universe, max_columns=16)
    second.load_private_state(load_state(file, 'a-private-test-passphrase'))
    _, keys = second.issue_user_keys('nurse-44', held)
    loaded = second.load_signed_package(package.record, package.signature,
                                        second.signer.public_key(),
                                        expected_channel='laboratory')
    assert second.open_verified(loaded, 'nurse-44', keys,
                                expected_channel='laboratory') == b'Clinical observations'


def test_key_store_catalog_binding(tmp_path):
    engine = AccessEngine(AlgebraGroup(77), ['a', 'b'])
    incompatible = AccessEngine(AlgebraGroup(77), ['a', 'c'])
    with pytest.raises(ValueError):
        incompatible.load_private_state(engine.private_state())
