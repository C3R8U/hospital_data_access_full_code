"""Independent workers return usable one-time offline ciphertext parts."""
import random
from healthshare.abe import AccessEngine
from healthshare.cache_parallel import fill_parallel
from healthshare.groups import AlgebraGroup
from healthshare.policy import build_policy


def test_parallel_offline_slots():
    universe = [f'c{i}' for i in range(40)]
    held = set(universe[::2])
    engine = AccessEngine(AlgebraGroup(seed=3), universe, max_columns=16, cache_depth=2)
    slots, stats = fill_parallel(engine, {'backend': 'algebra-check', 'seed': 7}, 2, 2)
    assert stats['generated_slots'] == 2
    assert stats['slots_per_second'] > 0
    assert slots[0].attr_parts['c0'][1] != slots[1].attr_parts['c0'][1]
    engine.cache = slots
    policy = build_policy(universe, held, 20, 20, random.Random(1))
    plaintext = b'Independent precomputed ciphertext slot'
    package, _, hit = engine.create(policy, plaintext)
    assert hit
    _, keys = engine.issue_user_keys('doctor-7', held)
    assert engine.open_verified(package, 'doctor-7', keys) == plaintext
