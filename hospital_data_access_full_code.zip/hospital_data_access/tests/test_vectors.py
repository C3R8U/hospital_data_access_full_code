"""Public arithmetic fixtures and signed-metadata checks."""
import base64
import hashlib
import json
from pathlib import Path
import pytest
from healthshare.vectors import create_known_answer

ROOT = Path(__file__).resolve().parents[1]


def test_known_answer():
    saved = json.loads((ROOT / "tests/vectors/decryption.json").read_text())
    calculated, engine, package, keys = create_known_answer()
    assert saved == calculated
    expected = calculated["inputs"]["R"]["exponent_mod_101"]
    assert calculated["intermediate"]["recovered_R"]["exponent_mod_101"] == expected
    assert calculated["intermediate"]["Z"]["exponent_mod_101"] == 19
    assert engine.open_verified(package, "clinical-reader", keys,
                                expected_channel="laboratory") == bytes.fromhex(
                                    calculated["expected"]["plaintext_hex"])


def test_ledger_metadata_and_version():
    trace, engine, package, keys = create_known_answer()
    ledger = {
        "digest": hashlib.sha256(package.record).hexdigest(),
        "policy_digest": json.loads(package.associated)["policy_digest"],
        "channel_id": "laboratory", "version": "1", "revoked": False,
        "owner_signature": base64.b64encode(package.signature).decode(),
    }
    assert engine.preverify(package, "laboratory", metadata=ledger)
    assert engine.open_verified(package, "clinical-reader", keys,
                                expected_channel="laboratory", metadata=ledger)
    for field, value in (("digest", "0" * 64), ("version", "2"),
                         ("channel_id", "clinical"), ("revoked", True),
                         ("owner_signature", "untrusted")):
        corrupted = dict(ledger)
        corrupted[field] = value
        assert not engine.preverify(package, "laboratory", metadata=corrupted)
        with pytest.raises(ValueError):
            engine.open_verified(package, "clinical-reader", keys,
                                 expected_channel="laboratory", metadata=corrupted)


def test_signed_package_other_channel():
    trace, engine, package, keys = create_known_answer()
    loaded = engine.load_signed_package(package.record, package.signature,
                                        engine.signer.public_key(),
                                        expected_channel="laboratory")
    assert loaded.record == package.record
    with pytest.raises(ValueError):
        engine.load_signed_package(package.record, package.signature,
                                   engine.signer.public_key(),
                                   expected_channel="clinical")
