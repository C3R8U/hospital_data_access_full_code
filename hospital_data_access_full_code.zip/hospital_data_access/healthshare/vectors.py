"""Small public group fixtures with fully specified arithmetic."""
from __future__ import annotations
import base64
import hashlib
import json
from dataclasses import asdict
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .abe import AccessEngine, AttributeKeys, Package, Slot, b64, canonical
from .groups import AlgebraGroup
from .policy import Policy


def create_known_answer():
    # Keep the fixture small enough that its exponents can be checked by hand.
    group = AlgebraGroup(seed=91, order=101)
    engine = AccessEngine(group, ["laboratory", "clinical"], authorities=2,
                          max_columns=2, cache_depth=1)
    engine.signer = Ed25519PrivateKey.from_private_bytes(bytes(range(32)))
    coefficients = {"laboratory": (11, 7, 5), "clinical": (17, 3, 9)}
    for index, (label, (alpha, y, _)) in enumerate(coefficients.items()):
        engine.attributes[label] = AttributeKeys(alpha, y, group.pow(engine.eg, alpha),
                                                group.pow(engine.g, y), index)
    v, w = [19, 4], [0, 6]
    E = [group.pow(engine.eg, exponent) for exponent in v]
    W = [group.identity("G"), group.pow(engine.g, w[1])]
    parts = {}
    for attr, (_, _, r) in coefficients.items():
        keys = engine.attributes[attr]
        parts[attr] = (group.pow(keys.A, r), group.pow(engine.g, r), group.pow(keys.B, r))
    slot = Slot(v=v, w=w, E=E, W=W, attr_parts=parts)
    policy = Policy([[1, 1], [0, -1]], ["laboratory", "clinical"],
                    [["laboratory"], ["clinical"]]).validate(max_columns=2)
    rows = []
    for matrix_row, attr in zip(policy.matrix, policy.labels):
        x, y, zz = slot.attr_parts[attr]
        c1, c3 = x, zz
        for col, value in enumerate(matrix_row):
            if value:
                c1 = group.mul(c1, group.pow(E[col], value))
                if col:
                    c3 = group.mul(c3, group.pow(W[col], value))
        rows.append((c1, y, c3))
    R = group.pow(engine.eg, 29)
    c0 = group.mul(R, E[0])
    salt, nonce = bytes(range(16)), bytes(range(12))
    policy_digest = hashlib.sha256(salt + canonical(policy.export())).hexdigest()
    associated = canonical({"channel": "laboratory", "policy_digest": policy_digest, "version": 1})
    plaintext = b"Group fixture for clinical access control"
    encrypted = AESGCM(engine._key(R, associated)).encrypt(nonce, plaintext, associated)
    confirmation = engine._confirm(R, associated)
    record = canonical({
        "policy": policy.export(),
        "rows": [[b64(group.serialize(value)) for value in triple] for triple in rows],
        "c0": b64(group.serialize(c0)), "encrypted": b64(encrypted),
        "nonce": b64(nonce), "associated": b64(associated),
        "salt": b64(salt), "confirmation": confirmation,
    })
    signature = engine.signer.sign(record)
    pkg = Package(policy, rows, c0, encrypted, nonce, associated, confirmation,
                  record, signature, engine.signer.public_key())
    gid, z = "clinical-reader", 3
    h, sk = engine.issue_user_keys(gid, set(policy.labels))
    inverse = pow(z, -1, group.order)
    blinded_h = group.pow(h, inverse)
    blinded_keys = {name: group.pow(key, inverse) for name, key in sk.items()}
    ratios = [group.div(group.pair(blinded_h, row[2]),
                        group.pair(blinded_keys[attr], row[1]))
              for row, attr in zip(rows, policy.labels)]
    P = engine.transform(pkg, blinded_h, blinded_keys)
    result = engine.recover_components(pkg, P, z, sk)
    decoded = engine.open_verified(pkg, gid, sk, expected_channel="laboratory",
                                  trusted_public_key=engine.signer.public_key())
    if decoded != plaintext or not group.equal(result["R"], R):
        raise AssertionError("The access key did not open the expected group element")
    def show(value):
        return {"kind": value.kind, "exponent_mod_101": value.power,
                "serialized_hex": group.serialize(value).hex()}
    trace = {
        "group": {"backend": group.name, "order": group.order,
                  "generator": show(engine.g), "base_pairing": show(engine.eg),
                  "security_use": "public arithmetic fixture only"},
        "inputs": {
            "gid": gid, "attribute_exponents": {
                name: {"alpha": alpha, "y": y, "r": r}
                for name, (alpha, y, r) in coefficients.items()},
            "matrix": policy.matrix, "labels": policy.labels,
            "v": v, "w": w, "reconstruction": result["coefficients"],
            "blinding_z": z, "blinding_inverse": inverse,
            "R": show(R), "salt_hex": salt.hex(), "nonce_hex": nonce.hex(),
            "plaintext_hex": plaintext.hex(),
        },
        "intermediate": {
            "H_gid": show(h),
            "user_keys": {name: show(value) for name, value in sk.items()},
            "blinded_H": show(blinded_h),
            "blinded_keys": {name: show(value) for name, value in blinded_keys.items()},
            "C1": [show(row[0]) for row in rows],
            "C2": [show(row[1]) for row in rows],
            "C3": [show(row[2]) for row in rows],
            "row_pairing_ratios": [show(value) for value in ratios],
            "C0": show(c0), "P": show(P),
            "L": show(result["L"]), "P_z": show(result["P_z"]),
            "Z": show(result["Z"]), "recovered_R": show(result["R"]),
            "confirmation_sha256": confirmation,
            "ciphertext_sha256": hashlib.sha256(record).hexdigest(),
            "encrypted_hex": encrypted.hex(), "associated_hex": associated.hex(),
            "owner_signature_hex": signature.hex(),
        },
        "expected": {"plaintext_hex": plaintext.hex(), "verified": True,
                     "recovered_R_matches": group.equal(R, result["R"])},
    }
    return trace, engine, pkg, sk
