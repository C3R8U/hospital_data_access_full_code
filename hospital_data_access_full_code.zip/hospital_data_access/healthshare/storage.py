"""Portable local object references for encrypted data files."""
from pathlib import Path
from urllib.parse import urlparse, unquote


def reference(file_path, root):
    relative = Path(file_path).resolve().relative_to(Path(root).resolve())
    return 'file:' + relative.as_posix()


def local_path(uri, root):
    parsed = urlparse(uri)
    if parsed.scheme != 'file' or parsed.netloc:
        raise ValueError('The object must use a local file reference')
    requested = Path(unquote(parsed.path))
    base = Path(root).resolve()
    destination = requested.resolve() if requested.is_absolute() else (base/requested).resolve()
    if not destination.is_relative_to(base):
        raise ValueError('The file reference is outside the data directory')
    return destination
