"""Monotone access trees and integer secret-sharing matrices."""
from __future__ import annotations
from dataclasses import dataclass
import random

@dataclass
class Policy:
    matrix: list[list[int]]
    labels: list[str]
    clauses: list[list[str]]

    def validate(self, max_clause_size=20, max_columns=16):
        if not self.matrix or len(self.matrix) != len(self.labels):
            raise ValueError("Every attribute must have one matrix row")
        width = len(self.matrix[0])
        if not 1 <= width <= max_columns:
            raise ValueError("The access matrix exceeds the column limit")
        if any(len(row) != width or any(value not in (-1, 0, 1) for value in row)
               for row in self.matrix):
            raise ValueError("Invalid access matrix coefficients")
        if len(self.labels) != len(set(self.labels)):
            raise ValueError("Attribute labels must be distinct")
        flattened = [attr for clause in self.clauses for attr in clause]
        if (not self.clauses or any(not 1 <= len(clause) <= max_clause_size for clause in self.clauses)
                or len(flattened) != len(self.labels) or set(flattened) != set(self.labels)):
            raise ValueError("The clauses do not match the matrix labels")
        return self

    @property
    def row_count(self): return len(self.labels)
    @property
    def column_count(self): return len(self.matrix[0])

    def witness(self, held: set[str]):
        # A surviving path through each OR clause completes the AND policy.
        found = []
        for clause in self.clauses:
            candidate = next((x for x in clause if x in held), None)
            if candidate is None: return None
            found.append(self.labels.index(candidate))
        coefficients = [int(i in found) for i in range(self.row_count)]
        reconstruction = [sum(coefficients[i] * self.matrix[i][j]
                              for i in range(self.row_count))
                          for j in range(self.column_count)]
        if reconstruction != [1] + [0] * (self.column_count - 1):
            raise ArithmeticError("The selected rows do not reconstruct the access secret")
        return coefficients

    def export(self):
        return {"matrix": self.matrix, "labels": self.labels, "clauses": self.clauses}


def build_policy(universe: list[str], held: set[str], size: int,
                 clause_size: int, rng: random.Random) -> Policy:
    if clause_size <= 0:
        raise ValueError("Clause size must be positive")
    if not 2 <= size <= len(universe):
        raise ValueError("Invalid number of policy rows")
    count = max(2, (size + clause_size - 1) // clause_size)
    allowed = sorted(held.intersection(universe))
    if len(allowed) < count: raise ValueError("Too few user attributes")
    anchors = rng.sample(allowed, count)
    remaining = [x for x in universe if x not in anchors]
    selected = anchors + rng.sample(remaining, size - count)
    fillers = selected[count:]
    rng.shuffle(fillers)
    clauses = [[a] for a in anchors]
    for i, attr in enumerate(fillers): clauses[i % count].append(attr)
    for clause in clauses: rng.shuffle(clause)

    # The left child of an AND gate receives v+e; the right receives -e.
    tree = ("or", clauses[0])
    for clause in clauses[1:]: tree = ("and", tree, ("or", clause))
    rows, width = [], 1
    def visit(node, vec):
        nonlocal width
        if isinstance(node, str): rows.append((node, dict(vec)))
        elif node[0] == "or":
            for item in node[1]: visit(item, vec)
        else:
            index = width
            width += 1
            left = dict(vec)
            left[index] = 1
            visit(node[1], left)
            visit(node[2], {index: -1})
    visit(tree, {0: 1})
    names = [x for x, _ in rows]
    matrix = [[v.get(i, 0) for i in range(width)] for _, v in rows]
    assert len(names) == size and len(set(names)) == size
    policy = Policy(matrix, names, clauses).validate(clause_size, 16)
    assert policy.witness(set(anchors)) is not None
    return policy
