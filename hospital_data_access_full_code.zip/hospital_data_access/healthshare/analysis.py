"""Measurement summaries for encrypted access and ledger workloads."""
from __future__ import annotations
import math
import statistics
from collections import defaultdict
from scipy.stats import t


def summary(values):
    values = list(map(float, values))
    if not values:
        raise ValueError('At least one observed value is required')
    n = len(values)
    mean = statistics.mean(values)
    sd = statistics.stdev(values) if n > 1 else 0.0
    margin = t.ppf(.975, n - 1) * sd / math.sqrt(n) if n > 1 else 0.0
    return {'n': n, 'mean': mean, 'sd': sd,
            'ci95_low': mean-margin, 'ci95_high': mean+margin}


def summarize_fabric(reports):
    grouped = defaultdict(list)
    for report in reports:
        if report['committed'] + report['failed'] != report['proposed']:
            raise ValueError('Unbalanced commit counts')
        if report['elapsed_seconds'] <= 0:
            raise ValueError('Invalid trial duration')
        if sum(ch['committed'] for ch in report['channels'].values()) != report['committed']:
            raise ValueError('Inconsistent per-channel commit counts')
        grouped[(report['layout'], int(report['rate_requested_tps']))].append(report)
    result = []
    for (layout, rate), runs in sorted(grouped.items()):
        values = [run['committed'] / run['elapsed_seconds'] for run in runs]
        result.append({
            'layout': layout, 'rate_requested_tps': rate,
            'committed_tps': summary(values),
            'offered_tps': summary(run['offered_tps'] for run in runs),
            'failed_count': sum(run['failed'] for run in runs),
            'skipped_concurrency': sum(run['skipped_concurrency'] for run in runs),
            'per_channel': {channel: summary(run['channels'][channel]['committed_tps']
                                            for run in runs)
                            for channel in sorted(runs[0]['channels'])},
        })
    return result


def compare_layouts(rows):
    indexed = {(r['layout'], r['rate_requested_tps']): r for r in rows}
    rates = sorted(set(rate for layout, rate in indexed))
    pairs = []
    for rate in rates:
        one, three = indexed.get(('single', rate)), indexed.get(('three', rate))
        if one is None or three is None:
            continue
        s = one['committed_tps']['mean']
        m = three['committed_tps']['mean']
        pairs.append({'rate_requested_tps': rate, 'single_tps': s,
                      'three_tps': m, 'speedup': m/s if s > 0 else None})
    return pairs


def summarize_blocks(blocks, max_message_count=20, batch_timeout_ms=100):
    by_channel = defaultdict(list)
    for block in blocks:
        if int(block['transaction_count']) < 0:
            raise ValueError('Negative transaction count')
        by_channel[block['channel']].append(block)
    result = []
    for channel, records in sorted(by_channel.items()):
        records.sort(key=lambda b: int(b['number']))
        sizes = [int(r['transaction_count']) for r in records]
        intervals = [(float(b['timestamp_ms']) - float(a['timestamp_ms']))
                     for a, b in zip(records, records[1:])]
        if any(interval < 0 for interval in intervals):
            raise ValueError('Block time must not decrease')
        result.append({
            'channel': channel, 'block_count': len(sizes),
            'total_transactions_in_blocks': sum(sizes),
            'full_blocks': sum(x >= max_message_count for x in sizes),
            'mean_block_transactions': statistics.mean(sizes),
            'mean_block_interval_ms': statistics.mean(intervals) if intervals else None,
            'interval_below_batch_timeout_count': sum(x < batch_timeout_ms for x in intervals),
        })
    return result
