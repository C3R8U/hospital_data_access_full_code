"""Encrypted local storage for authority keys and the owner signing key."""
from __future__ import annotations
import json
import os
import secrets
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

ASSOCIATED = b'hospital-share:authority-keys:v1'


def derive_key(passphrase, salt):
    if len(passphrase) < 12:
        raise ValueError('A passphrase must have at least twelve characters')
    return Scrypt(salt=salt, length=32, n=2**14, r=8, p=1).derive(passphrase.encode())


def save_state(path, state, passphrase):
    destination = Path(path)
    if destination.exists():
        raise FileExistsError('The key store already exists')
    destination.parent.mkdir(parents=True, exist_ok=True)
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    payload = json.dumps(state, sort_keys=True, separators=(',', ':')).encode()
    sealed = AESGCM(derive_key(passphrase, salt)).encrypt(nonce, payload, ASSOCIATED)
    envelope = json.dumps({'format': 'authority-keys-v1', 'salt': salt.hex(),
                           'nonce': nonce.hex(), 'ciphertext': sealed.hex()}).encode()
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(envelope)
    except BaseException:
        destination.unlink(missing_ok=True)
        raise


def load_state(path, passphrase):
    contents = json.loads(Path(path).read_text())
    if contents.get('format') != 'authority-keys-v1':
        raise ValueError('Unknown key store format')
    salt, nonce = bytes.fromhex(contents['salt']), bytes.fromhex(contents['nonce'])
    payload = AESGCM(derive_key(passphrase, salt)).decrypt(
        nonce, bytes.fromhex(contents['ciphertext']), ASSOCIATED)
    return json.loads(payload)
