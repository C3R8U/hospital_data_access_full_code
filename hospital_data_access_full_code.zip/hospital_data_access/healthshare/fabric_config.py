"""Channel membership, endorsement, and batch settings."""
from __future__ import annotations
import json
from pathlib import Path


def load_network(path):
    network = json.loads(Path(path).read_text(encoding="utf-8"))
    if network["consensus"] != "Raft" or len(network["orderers"]) != 3:
        raise ValueError("The ordering service has an unexpected configuration")
    batching = network["batching"]
    if (batching["max_message_count"] != 20 or batching["batch_timeout_ms"] != 100
            or batching["preferred_max_bytes"] != 524288):
        raise ValueError("Unexpected channel batching parameters")
    orgs = network["organisations"]
    if len(orgs) != 3 or sum(len(x["peers"]) for x in orgs.values()) != 6:
        raise ValueError("The network requires six peers in three organizations")
    for name, channel in network["channels"].items():
        if not set(channel["endorsers"]).issubset(channel["members"]):
            raise ValueError(f"Missing endorsing organization in {name}")
        if len(channel["endorsers"]) != 2:
            raise ValueError(f"Expected two independent endorsers for {name}")
        allowed = set().union(*(set(orgs[org]["peers"]) for org in channel["members"]))
        if not set(channel["peers"]).issubset(allowed):
            raise ValueError(f"A channel peer is not a member of {name}")
    return network


def transaction_rate_bounds(transactions_per_block, channel_count, timeout_ms,
                            completed_transactions=None, elapsed_seconds=None):
    # A timeout controls the waiting tail; a full block may close earlier.
    paced_rate = 1000 * transactions_per_block * channel_count / timeout_ms
    result = {"fixed_timeout_baseline_tps": paced_rate,
              "batch_timeout_is_hard_tps_limit": False}
    if completed_transactions is not None and elapsed_seconds is not None:
        if elapsed_seconds <= 0:
            raise ValueError("Measurement duration must be positive")
        actual = completed_transactions / elapsed_seconds
        result["confirmed_tps"] = actual
        result["full_block_interval_ms_per_channel"] = (
            1000 * transactions_per_block * channel_count / actual if actual > 0 else None)
    return result
