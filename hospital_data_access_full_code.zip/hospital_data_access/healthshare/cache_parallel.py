"""Independent offline group arithmetic across worker processes."""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import secrets
import time
from pathlib import Path
from .abe import Slot
from .groups import AlgebraGroup, PBCGroup


def _group(settings):
    if settings['backend'] == 'algebra-check':
        return AlgebraGroup(settings['seed'], order=settings.get('order', 2**127 - 1))
    return PBCGroup(settings['parameters'], settings['generator'], settings['library'])


def _slot_worker(settings, public_attributes, columns):
    group = _group(settings)
    started = time.perf_counter_ns()
    E = [group.pow(group.base_pair(), group.random_scalar()) for _ in range(columns)]
    W = [group.identity('G')] + [group.pow(group.generator(), group.random_scalar())
                                  for _ in range(columns - 1)]
    attr_parts = {}
    for name, (a_hex, b_hex) in public_attributes.items():
        a, b = group.deserialize(bytes.fromhex(a_hex)), group.deserialize(bytes.fromhex(b_hex))
        r = group.random_scalar()
        attr_parts[name] = tuple(group.serialize(x).hex() for x in (
            group.pow(a, r), group.pow(group.generator(), r), group.pow(b, r)))
    duration_ms = (time.perf_counter_ns() - started) / 1e6
    result = {
        'E': [group.serialize(x).hex() for x in E],
        'W': [group.serialize(x).hex() for x in W],
        'attr_parts': attr_parts, 'compute_ms': duration_ms,
    }
    if hasattr(group, 'close'): group.close()
    return result


def fill_parallel(engine, backend_settings, workers, slots):
    if workers < 1 or slots < 1:
        raise ValueError('Workers and slot counts must be positive')
    group = engine.group
    public = {name: (group.serialize(data.A).hex(), group.serialize(data.B).hex())
              for name, data in engine.attributes.items()}
    started = time.perf_counter_ns()
    tasks = []
    for _ in range(slots):
        item = dict(backend_settings)
        if item['backend'] == 'algebra-check':
            item['seed'] = secrets.randbits(126)
        tasks.append(item)
    with ProcessPoolExecutor(max_workers=workers, mp_context=get_context('spawn')) as pool:
        raw = list(pool.map(_slot_worker, tasks,
                            [public] * slots, [engine.max_columns] * slots))
    duration_s = (time.perf_counter_ns() - started) / 1e9
    converted = []
    for item in raw:
        converted.append(Slot(v=[], w=[],
                              E=[group.deserialize(bytes.fromhex(x)) for x in item['E']],
                              W=[group.deserialize(bytes.fromhex(x)) for x in item['W']],
                              attr_parts={name: tuple(group.deserialize(bytes.fromhex(value))
                                                      for value in parts)
                                          for name, parts in item['attr_parts'].items()}))
    return converted, {'workers': workers, 'generated_slots': slots,
                       'wall_seconds': duration_s, 'slots_per_second': slots/duration_s,
                       'mean_worker_compute_ms': sum(r['compute_ms'] for r in raw)/len(raw)}
